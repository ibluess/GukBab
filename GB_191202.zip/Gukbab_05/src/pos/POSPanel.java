package pos;
//�ǸŰ��� mysql���� �Ϸ�
import java.sql.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

public class POSPanel extends JPanel {
   JButton[] MBtn = new JButton[9];
   String[] menu = { "�� �� �� ��", "�� �� �� ��", "�� �� �� ��", "�� �� �� ��", "�� ��", "�� �� ��", "ȯ Ÿ", "�� ��", "�� ��" };
   int[] price = { 7000, 6500, 8000, 7000, 1000, 1000, 2000, 4500, 4000 };
   JTextField tf = new JTextField(20);

   JButton[] MGRtn = new JButton[1];
   String[] MGR = { "�Ǹ� ����" };

   JTextField t = new JTextField(10);

   JButton[] SBtn = new JButton[4];
   String[] Str = { "����", "�κ����", "��ü���", "����" };

   String[] ColName = { "�޴�", "����", "����" };

   String[][] Data;
   int count = 1;
   DefaultTableModel model = new DefaultTableModel(Data, ColName);
   JTable table = new JTable(model);

   Image[] icon = new Image[9];
   Image[] newimg = new Image[9];
   ImageIcon[] newicon = new ImageIcon[9];

   // ����
   class Screen extends JPanel {
      Screen() {
         setBackground(Color.RED);
         DefaultTableModel m = (DefaultTableModel) table.getModel();
         table.setRowHeight(40); // �޴����ý� ����â ����
         table.getTableHeader().setFont(new Font("�ü�", Font.BOLD, 15));
         add(new JScrollPane(table));
      }
   } // ��ư����, ���� ����

   class MenuBtn extends JPanel {
      MenuBtn() {
         setLayout(new GridLayout(3, 3, 3, 3));
         setBackground(Color.YELLOW);
         ImageIcon[] img = new ImageIcon[9];
         img[0] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\sun.jpg");
         img[1] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\soo.jpg"); // ��� �����ؾ���
         img[2] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\bone.jpg");
         img[3] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\pig.jpg");
         img[4] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\coke.jpg");
         img[5] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\cider.jpg");
         img[6] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\fanta.jpg");
         img[7] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\soju.jpg");
         img[8] = new ImageIcon("C:\\Users\\lg\\Desktop\\����\\imgs\\imgs\\beer.jpg");

         for (int i = 0; i < img.length; i++) {
            icon[i] = img[i].getImage();
            newimg[i] = icon[i].getScaledInstance(140, 140, Image.SCALE_AREA_AVERAGING);
            newicon[i] = new ImageIcon(newimg[i]);
         }
         // Image.SCALE_DEFAULT : �⺻ �̹��� �����ϸ� �˰����� ���
         // Image.SCALE_FAST : �̹��� �ε巯�򺸴� �ӵ� �켱
         // Image.SCALE_SMOOTH : �ӵ����� �̹��� �ε巯���� �켱
         // Image.SCALE_AREA_AVERAGING : ��� �˰����� ���
         for (int i = 0; i < MBtn.length; i++) {
            MBtn[i] = new JButton(newicon[i]);
            MBtn[i].setBorderPainted(false);
            MBtn[i].setContentAreaFilled(false);
            add(MBtn[i]);
         }
      }
   } // �޴��� ��ư ���̾ƿ�����, ����κ�

   class MGRBtn extends JPanel {
      MGRBtn() {
         setBackground(Color.WHITE);
         setLayout(new GridLayout(1, 1, 1, 1));

         for (int i = 0; i < MGR.length; i++) {
            MGRtn[i] = new JButton(MGR[i]);
            add(MGRtn[i]);
         }
      }
   }// �ǸŰ�����ư ���̾ƿ� ����

   class StrBtn extends JPanel {
      StrBtn() {
         setBackground(Color.ORANGE);
         setLayout(new GridLayout(1, 4, 3, 3));

         for (int i = 0; i < Str.length; i++) {
            SBtn[i] = new JButton(Str[i]);
            add(SBtn[i]);
         }
      }
   } // ����~���� ��ư ���̾ƿ�����, ��� ��Ȳ�κ�

   public POSPanel() {
      setLayout(null);
      setBackground(Color.GREEN);
      MenuBtn mbtn = new MenuBtn();
      MGRBtn mgrtn = new MGRBtn();
      StrBtn sbtn = new StrBtn(); // ��ư�迭
      Screen sc = new Screen();

   // ����ǥ�ö� 
      //tf.setSize(450, 70);
      tf.setSize(500, 100);
      //tf.setLocation(50, 480);
      tf.setLocation(60, 480);
      add(tf);
      
      //���� �޴� ǥ�ö�
      //sc.setSize(500, 500);
      sc.setSize(600, 600);
      //sc.setLocation(70, 20);
      sc.setLocation(25, 20);
      add(sc);

      //mbtn.setSize(400, 350); // �޴���ư ������ (����, ����)
      mbtn.setSize(500, 400); // �޴���ư ������ (����, ����)
      //mbtn.setLocation(530, 23); // �޴���ư ��ġ
      mbtn.setLocation(700, 23); // �޴���ư ��ġ
      add(mbtn);

      //mgrtn.setSize(400, 70); // ������ư
      mgrtn.setSize(500, 70); // ������ư
      //mgrtn.setLocation(530, 400);
      mgrtn.setLocation(700, 450);
      add(mgrtn);

      //sbtn.setSize(400, 70); // ������ư
      sbtn.setSize(500, 70); // ������ư
      //sbtn.setLocation(530, 480);
      sbtn.setLocation(700, 550);
      add(sbtn);

      for (int i = 0; i < MBtn.length; i++) { // ����â ��� �κ�
         final int index = i;
         MBtn[i].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               JButton MBtn = (JButton) e.getSource();
               DefaultTableModel m = (DefaultTableModel) table.getModel();
               m.addRow(new Object[] { menu[index], count, price[index] });
            }
         });
      }
      SBtn[0].addActionListener(new ActionListener() { // ���� ��ư
         @Override
         public void actionPerformed(ActionEvent e) {
            JButton MBtn = (JButton) e.getSource();
            table.setValueAt(0, table.getSelectedRow(), 2);
         }
      });

      SBtn[1].addActionListener(new ActionListener() { // �κ���� ��ư
         @Override
         public void actionPerformed(ActionEvent e) {
            JButton MBtn = (JButton) e.getSource();
            DefaultTableModel m = (DefaultTableModel) table.getModel();

            m.removeRow(table.getSelectedRow());
         }
      });

      SBtn[2].addActionListener(new ActionListener() { // ��ü��� ��ư
         @Override
         public void actionPerformed(ActionEvent e) {
            JButton MBtn = (JButton) e.getSource();
            DefaultTableModel m = (DefaultTableModel) table.getModel();

            m.setRowCount(0);
            tf.setText(String.valueOf(""));
         }
      });

      SBtn[3].addActionListener(new ActionListener() { // ���� ��ư
         @Override
         public void actionPerformed(ActionEvent e) {
            JButton MBtn = (JButton) e.getSource();
            int rowCont = table.getRowCount();

            int sundae = 0;
            int suyuk = 0;
            int bone = 0;
            int pig = 0;
            int sum = 0;

            for (int i = 0; i < rowCont; i++) {
               if (table.getValueAt(i, 0).equals("�� �� �� ��"))
                  sundae += (int) table.getValueAt(i, 1);
               else if (table.getValueAt(i, 0).equals("�� �� �� ��"))
                  suyuk += (int) table.getValueAt(i, 1);
               else if (table.getValueAt(i, 0).equals("�� �� �� ��"))
                  bone += (int) table.getValueAt(i, 1);
               else if (table.getValueAt(i, 0).equals("�� �� �� ��"))
                  pig += (int) table.getValueAt(i, 1);
            }

            for (int i = 0; i < rowCont; i++)
               sum += (int) table.getValueAt(i, 2);

            tf.setText(String.valueOf(" �� �ݾ� : " + sum + "��"));
            tf.setFont(new Font("����ü", Font.BOLD, 40));

            Connection conn = null;
            Statement stmt = null;
            try {
               Class.forName("com.mysql.cj.jdbc.Driver");
               String url = "jdbc:mysql://localhost/db?serverTimezone=UTC";
               conn = DriverManager.getConnection(url, "root", "tmfql1123");

               stmt = conn.createStatement();
               stmt.executeUpdate("update sundae set count= count +" + sundae);
               stmt.executeUpdate("update suyuk set count= count +" + suyuk);
               stmt.executeUpdate("update bone set count= count +" + bone);
               stmt.executeUpdate("update pig set count= count +" + pig);
               stmt.executeUpdate("update sales set profit= profit +" + sum);

               JOptionPane.showMessageDialog(null, "�����Ǿ����ϴ�.", "����", JOptionPane.DEFAULT_OPTION); // DB�� ������ ������
              
               DefaultTableModel m = (DefaultTableModel) table.getModel();

               m.setRowCount(0);
               tf.setText(String.valueOf(""));
            } catch (ClassNotFoundException e1) {
               System.out.println("DB���� ����");
            } catch (SQLException e1) {
               System.out.println("error : " + e1);
            } finally {
               try {
                  if (conn != null && !conn.isClosed())
                     conn.close();
               } catch (SQLException e1) {
                  e1.printStackTrace();
               }
            }

         }
      });

      MGRtn[0].addActionListener(new ActionListener() {// �ǸŰ��� ��ư�� ������ ��
         @Override
         public void actionPerformed(ActionEvent e) {
            Connection conn = null;
            Statement stmt = null;
            try {
               Class.forName("com.mysql.cj.jdbc.Driver");
               String url = "jdbc:mysql://localhost/db?serverTimezone=UTC";

               conn = DriverManager.getConnection(url, "root", "tmfql1123");
               stmt = conn.createStatement();

               Dimension dim = new Dimension(400, 150);

               JFrame Frame = new JFrame("�ǸŰ���"); // GUI�� �⺻ â �����
               Frame.setSize(800, 600); // ũ�⸦ ������ ���� ������, â�� �ʹ� �۰� ����
               Frame.setVisible(true); // â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
               Frame.setPreferredSize(dim);

               String name[] = { "�޴�", "�Ǹ�Ƚ��" };
               String data[][] = { 
                     { "                      ���뱹��", "" }, 
                     { "                      �����屹", "" },
                     { "                      ��������", "" }, 
                     { "                      ��������", "" },
                     { "                      ��������", "" } };
               DefaultTableModel model = new DefaultTableModel(data, name);

               JTable table = new JTable(model);
               JScrollPane scrollpane = new JScrollPane(table);
               Frame.add(scrollpane);
               Frame.pack();
               Frame.setVisible(true);

               ResultSet srs1 = stmt.executeQuery("select * from sundae");
               InsertData(srs1, "sundae_count", model);
               srs1.close();

               ResultSet srs2 = stmt.executeQuery("select * from suyuk");
               InsertData(srs2, "suyuk_count", model);
               srs2.close();

               ResultSet srs3 = stmt.executeQuery("select * from bone");
               InsertData(srs3, "bone_count", model);
               srs3.close();

               ResultSet srs4 = stmt.executeQuery("select * from pig");
               InsertData(srs4, "pig_count", model);
               srs4.close();

               ResultSet srs = stmt.executeQuery("select * from sales");
               InsertData(srs, "profit", model);
               srs.close();
               
            } catch (ClassNotFoundException e1) {
               System.out.println("DB���� ����");
            } catch (SQLException e1) {
               System.out.println("error : " + e1);
            } finally {
               try {
                  if (conn != null && !conn.isClosed()) {
                     conn.close();
                  }
               } catch (SQLException e1) {
                  e1.printStackTrace();
               }
            }
         }
      });
      ;
   }
   private static void InsertData(ResultSet srs, String col1, DefaultTableModel model) throws SQLException { // ������ db������ ����Լ�
      while (srs.next()) {
         if (col1.equals("sundae_count")) {
            model.setValueAt(srs.getInt("count")+"��", 0, 1);
            break;
         } else if (col1.equals("suyuk_count")) {
            model.setValueAt(srs.getInt("count")+"��", 1, 1);
            break;
         } else if (col1.equals("bone_count")) {
            model.setValueAt(srs.getInt("count")+"��", 2, 1);
            break;
         } else if (col1.equals("pig_count")) {
            model.setValueAt(srs.getInt("count")+"��", 3, 1);
            break;
         } else if (col1.equals("profit")) {
            model.setValueAt(srs.getInt("profit")+"��", 4, 1);
            break;
         } else
            System.out.println();
      }
   }
}